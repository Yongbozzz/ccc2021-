#include "top.hpp"

bool operator<(const edge& e1, const edge& e2) {
    return e1.weight > e2.weight;
}

bool operator>(const edge& e1, const edge& e2) {
    return e1.weight < e2.weight;
}
edge mst2[41595];
int len_mst;
void prim(unsigned int allVert,
                       unsigned int allEdge,
                       unsigned int source,
                       unsigned int offset[3535],
                       unsigned int column[41595],
                       float weight[41595]) {
    int mstVert[3535]={0};
    edge e;
    e.from=0;
    e.to=0;
    e.weight=0;
    //std::priority_queue<edge> q;
    edge q[41595];
    for(int i=0;i<allVert;i++){
    		#pragma HLS unroll 
    	q[i]=e;
    }
    mstVert[source]=1;
    int len_q=0;
    int k=0;
    for (int i = offset[source]; i < offset[source + 1]; i++) {
    		#pragma HLS unroll 
        edge tmp;
        tmp.from = source;
        tmp.to = column[i];
        tmp.weight = weight[i];
        q[len_q]=tmp;
        len_q++;
    }
    int cnt = 0;
    float totalweight = 0.0;
    while (len_q>0) {
    	edge tmp=q[0];
    	int j=0;
    	for(int i=1;i<len_q;i++){
    		if(q[i]>tmp){
    			tmp=q[i];
    			j=i;
    		}
    	}
        //edge tmp = q.top();
        //q.pop();
    	for(int i=j;i<len_q-1;i++){
    		#pragma HLS unroll 
    		q[i]=q[i+1];
    	}
    	len_q--;
        if (mstVert[tmp.to] == 0) {
            mstVert[tmp.to]=1;
            totalweight = totalweight + tmp.weight;
            mst2[len_mst]=tmp;
            len_mst++;
            for (int i = offset[tmp.to]; i < offset[tmp.to + 1]; i++) {
                edge out;
                out.from = tmp.to;
                out.to = column[i];
                out.weight = weight[i];
                if (mstVert[out.to]==0){
                	q[len_q]=out;
                	len_q++;
                }
            }
        }
        cnt++;
    }

    //return mst;
}

void dut(unsigned int numVert,
         unsigned int numEdge,
         unsigned int offset[3535],
         unsigned int column[41595],
         float weight[41595],
         unsigned mst[3535],
         unsigned tmp0[1],
         unsigned tmp1[1],
         unsigned tmp2[1],
         unsigned tmp3[1]) {
	tmp0[0]=0;
	tmp1[0]=0;
	tmp2[0]=0;
	tmp3[0]=0;
    //std::vector<edge> mst_prim;
    unsigned sourceID = 0;

    prim(numVert, numEdge, sourceID, offset, column, weight);

    for (int i = 0; i < numVert; i++) {
#pragma HLS unroll 
        mst[i] = 0xFFFFFFFF;
    }
    mst[sourceID] = sourceID;
    for (int i=0;i<len_mst;i++) {
#pragma HLS unroll
        mst[mst2[i].to] = mst2[i].from;
    }
}

