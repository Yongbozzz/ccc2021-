#include <queue>
#include <set>
#include <iostream>

#define INTERFACE_MEMSIZE (100000)

class edge {
   public:
    unsigned int from;
    unsigned int to;
    float weight;
};
void dut(unsigned int numVert,
         unsigned int numEdge,
         unsigned int offset[3535],
         unsigned int column[41595],
         float weight[41595],
         unsigned mst[3535],
         unsigned tmp0[1],
         unsigned tmp1[1],
         unsigned tmp2[1],
         unsigned tmp3[1]) ;
