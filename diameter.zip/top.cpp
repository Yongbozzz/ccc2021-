#include "top.hpp"



template <typename MType>
union f_cast;

template <>
union f_cast<float> {
    float f;
    uint32_t i;
};

void sssp(unsigned numVert,
          unsigned numEdge,
          unsigned source,
          unsigned offset[3535],
          unsigned column[41595],
          float weight[41595],
          unsigned distance[3535]){
#pragma HLS ARRAY_PARTITION variable=distance dim=1 factor=4 cyclic
#pragma HLS ARRAY_PARTITION variable=offset dim=1 factor=4 cyclic
    loop1:for (int i = 0; i < numVert; i++) {
#pragma HLS unroll
        f_cast<float> init;
        init.f = std::numeric_limits<float>::infinity();
        distance[i] = init.i;
    }
    unsigned que[41595]={0};
    unsigned tail=0,head=0;
    que[tail]=source;
    tail++;
    f_cast<float> init;
    init.f = 0.0;
    distance[source] = init.i;

    while (head<tail) {
        unsigned tmp = que[head];
        loop2:for (int i = offset[tmp]; i < offset[tmp + 1]; i++) {
#pragma HLS unroll
            f_cast<float> fromDist;
            fromDist.i = distance[tmp];
            f_cast<float> toDist;
            toDist.i = distance[column[i]];
            f_cast<float> curDist;
            curDist.f = fromDist.f + weight[i];
            if (curDist.f < toDist.f) {
                distance[column[i]] = curDist.i;
                que[tail]=column[i];
                tail++;
                //q.push(column[i]);
            }
        }
        head++;
    }
}

void dut(unsigned numVert,
         unsigned numEdge,
         unsigned offset[3535],
         unsigned column[41595],
         float weight[41595],
         float max_dist[1],
         unsigned src[1],
         unsigned des[1],

         unsigned tmp0[3535],
         unsigned tmp1[1],
         unsigned tmp2[1],
         unsigned tmp3[1]) {

    max_dist[0] = 0;
    tmp1[0]=1;
    tmp2[0]=1;
    tmp3[0]=1;

    //loop3:for (int i = 0; i < 50; i++) {
        unsigned source = 0;
        sssp(numVert, numEdge, source, offset, column, weight, tmp0);
        loop5:for (int i = 0; i < 100; i++) {
#pragma HLS unroll
            f_cast<float> res;
            res.i = tmp0[i];
            if (res.f != std::numeric_limits<float>::infinity() && res.f > max_dist[0]) {
                max_dist[0] = res.f;
                src[0] = source;
                des[0] = i;
                //if(i>5)break;
            }
        }
	//}

}

