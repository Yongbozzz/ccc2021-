#include "sobel.h"
void sobel(PIXEL src[HEIGHT * WIDTH], PIXEL dst[(HEIGHT - 2) * (WIDTH - 2)], int rows, int cols)
{
	//#pragma HLS dataflow
	//	PIXEL temp[3][3];
	PIXEL buffer[362][1280];
	//PIXEL buffer[362][1280];
#pragma HLS ARRAY_PARTITION variable=buffer dim=2 factor=128 cyclic
#pragma HLS ARRAY_PARTITION variable=buffer dim=2 factor=128 cyclic
#pragma HLS ARRAY_PARTITION variable=src dim=1 factor=128 cyclic
#pragma HLS ARRAY_PARTITION variable=dst dim=1 factor=18 cyclic
//		int i;
//		int j;
	//for(int k=0;k<320;k+=98){
		lop3:for(int j=0;j<0+360;j++){
//#pragma HLS unroll
			loop1:for(int i = 0; i < 1280; i++)
			{
			#pragma HLS unroll factor=128
				buffer[j][i]=src[i+1280*(j)];
			}
		}

		for(int j=2;j<360;j++){
			for(int i=2;i<1280;i++){
	#pragma hls unroll
				int res=buffer[j-2][i] - buffer[j-2][i-2] + ((buffer[j-1][i] - buffer[j-1][i-2]) << 1) + buffer[j][i] - buffer[j][i-2];
				if(res<0) res=0;
				int res1=buffer[j][i-2] + buffer[j][i] - buffer[j-2][i-2] - buffer[j-2][i] + ((buffer[j][i-1] - buffer[j-2][i-1]) << 1);
				if(res1<0) res1=0;
				PIXEL rest=res+res1;
				if(rest>255) rest=255;
				dst[(j - 2) * (WIDTH - 2) + i-2] = rest;
			}
		}
	//}
		for(int j=358;j<720;j++){
			for(int i = 0; i < 1280; i++)
			{
	#pragma HLS unroll factor=128
				buffer[j-358][i]=src[i+1280*j];
			}
		}
		for(int j=360;j<720;j++){
			for(int i=2;i<1280;i++){
	#pragma hls unroll
				int res=buffer[j-2-358][i] - buffer[j-2-358][i-2] + ((buffer[j-1-358][i] - buffer[j-1-358][i-2]) << 1) + buffer[j-358][i] - buffer[j-358][i-2];
				if(res<0) res=0;
				int res1=buffer[j-358][i-2] + buffer[j-358][i] - buffer[j-2-358][i-2] - buffer[j-2-358][i] + ((buffer[j-358][i-1] - buffer[j-2-358][i-1]) << 1);
				if(res1<0) res1=0;
				PIXEL rest=res+res1;
				if(rest>255) rest=255;
				dst[(j - 2) * (WIDTH - 2) + i-2] = rest;
			}
		}
}

